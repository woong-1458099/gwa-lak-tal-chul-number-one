from django.db import models


class Author(models.Model):
  name = models.CharField(max_length=100)
  bio = models.TextField(blank=True)

  def __str__(self):
    return self.name


class Genre(models.Model):
  name = models.CharField(max_length=50, unique=True)

  def __str__(self):
    return self.name


class Book(models.Model):
  title = models.CharField(max_length=200)
  author = models.ForeignKey(Author, on_delete=models.CASCADE, related_name="books")
  genre = models.ForeignKey(Genre, on_delete=models.SET_NULL, null=True, related_name="books")
  published_date = models.DateField(null=True, blank=True)
  description = models.TextField(blank=True)

  def __str__(self):
    return self.title


class Review(models.Model):
  book = models.ForeignKey(Book, on_delete=models.CASCADE, related_name="reviews")
  content = models.TextField()
  rating = models.IntegerField()  # 1~5
  created_at = models.DateTimeField(auto_now_add=True)

  def __str__(self):
    return f"Review({self.book_id})-{self.rating}"

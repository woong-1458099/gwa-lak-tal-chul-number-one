from django.apps import AppConfig


class LibraryManagementsConfig(AppConfig):
  default_auto_field = "django.db.models.BigAutoField"
  name = "library_managements"

from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework import status
from django.shortcuts import get_object_or_404
from .models import Author, Genre, Book, Review
from .serializers import (
  AuthorBasicSerializer,
  GenreSerializer,
  BookListSerializer,
  BookDetailSerializer,
  BookCreateUpdateSerializer,
  ReviewSerializer,
)


# Books
@api_view(["GET", "POST"])
def books(request):
  if request.method == "GET":
    queryset = Book.objects.select_related("author").all()
    serializer = BookListSerializer(queryset, many=True)
    return Response(serializer.data)

  if request.method == "POST":
    serializer = BookCreateUpdateSerializer(data=request.data)
    serializer.is_valid()
    book = serializer.save()
    detail = BookDetailSerializer(book)
    return Response(detail.data, status=status.HTTP_201_CREATED)


@api_view(["GET", "PUT", "DELETE"])
def book_detail(request, pk):
  book = get_object_or_404(Book.objects.select_related("author", "genre"), pk=pk)

  if request.method == "GET":
    serializer = BookDetailSerializer(book)
    return Response(serializer.data)

  if request.method == "PUT":
    serializer = BookCreateUpdateSerializer(book, data=request.data)
    serializer.is_valid(raise_exception=True)
    serializer.save()
    serializer = BookDetailSerializer(book)
    return Response(serializer.data)

  if request.method == "DELETE":
    book.delete()
    return Response(status=status.HTTP_204_NO_CONTENT)


@api_view(["POST"])
def book_reviews_create(request, pk):
  pass


@api_view(["GET"])
def book_reviews_sorted(request, pk, sort_by): 
  book = get_object_or_404(Book, pk=pk)

  qs = book.reviews.all()

  serializer = ReviewSerializer(qs, many=True)
  return Response(serializer.data)


@api_view(["GET"])
def author_detail(request, author_id):
  author = Author.objects.get(pk=author_id)
  serializer = AuthorBasicSerializer(author)
  return Response(serializer.data)

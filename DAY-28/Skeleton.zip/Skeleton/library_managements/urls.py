from django.urls import path
from . import views

urlpatterns = [
  path("books/", views.books),
  path("books/<int:pk>/", views.book_detail),
  path("books/<int:pk>/reviews/", views.book_reviews_create),
  path("books/<int:pk>/reviews/<str:sort_by>/", views.book_reviews_sorted),

  path("authors/<int:author_id>/", views.author_detail),
]

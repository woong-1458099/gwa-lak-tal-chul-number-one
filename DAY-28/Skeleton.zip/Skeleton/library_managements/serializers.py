from rest_framework import serializers
from .models import Author, Genre, Book, Review


class AuthorBasicSerializer(serializers.ModelSerializer):

  class Meta:
    model = Author
    fields = '__all__'


class GenreSerializer(serializers.ModelSerializer):
  class Meta:
    model = Genre
    fields = ["id", "name"]


class ReviewSerializer(serializers.ModelSerializer):
  class Meta:
    model = Review
    fields = ["id", "content", "rating", "created_at"]


class BookListSerializer(serializers.ModelSerializer):
  author = AuthorBasicSerializer(read_only=True)

  class Meta:
    model = Book
    fields = "__all__"


class BookDetailSerializer(serializers.ModelSerializer):
  author = AuthorBasicSerializer(read_only=True)
  genre = GenreSerializer(read_only=True)

  class Meta:
    model = Book
    fields = ["id", "title", "author", "genre", "published_date", "description"]


class BookCreateUpdateSerializer(serializers.ModelSerializer):
  class Meta:
    model = Book
    fields = ["title", "author", "genre", "published_date", "description"]

from django import forms
from .models import Item

# 문제 7. 상품 등록 필드 요소 제한하기 (discount 필드 제한)
class ItemForm(forms.ModelForm):
    class Meta:
        model = Item
        fields = '__all__'
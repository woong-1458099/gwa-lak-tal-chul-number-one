from django.urls import path
from . import views

app_name = 'shops'
urlpatterns = [
    path('', views.index, name='index'),
    path('create/', views.create, name='create'),
    path('<int:item_pk>/', views.detail, name='detail'),
    path('update/<int:item_pk>/', views.update, name='update'),
    path('delete/<int:item_pk>/', views.delete, name='delete'),
    path('info/', views.info, name='info'),
]

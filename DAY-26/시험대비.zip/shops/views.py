from django.shortcuts import render, redirect

from .models import Item
from .forms import ItemForm

# 문제 1번. 인덱스 페이지 출력 요소 수정하기
def index(request):
    item_list = Item.objects.all()
    context = {
        'items': item_list,
    }
    return render(request, 'shops/index.html', context)


def create(request):
    if request.method == 'POST':
        form = ItemForm(request.POST, request.FILES)
        if form.is_valid():
            item = form.save()
            return redirect('shops:index')
        
    else:
        form = ItemForm()
    
    context = {
        'form': form,
    }
    return render(request, 'shops/create.html', context)


def detail(request, item_pk):
    item = Item.objects.get(pk=item_pk)
    context = {
        'item': item,
    }
    return render(request, 'shops/detail.html', context)

# 문제 6. 상품 수정 기능 오작동 디버깅
def update(request, item_pk):
    item = Item.objects.get(pk=item_pk)
    if request.method == 'POST':
        form = ItemForm(request.POST, request.FILES, instance=item)
        if form.is_valid():

            return redirect('shops:detail', item_pk)
    else:
        form = ItemForm(instance=item)
    
    context = {
        'form': form,
    }
    return render(request, 'shops/update.html', context)


# 문제 4. 잘못된 방식의 삭제 이슈 
def delete(request, item_pk):
    item = Item.objects.get(pk=item_pk)
    item.delete()
    return render(request, 'shops/delete.html')


def info(request):
    return render(request, 'shops/info.html')